
let offset = 0;
// находим кнопку по селектору
const sliderRow = document.querySelector('.slider-row');
const sliderPrev = document.querySelector('.slider-prev');
const sliderNext = document.querySelector('.slider-next');

// при нажатии на кнопку, будет происходить передвижение картинок

sliderNext.addEventListener('click', function() {
    offset = offset + 400;
    if (offset > 800) {
        offset = 0;
    }
    sliderRow.style.left = -offset + 'px';
});

sliderPrev.addEventListener('click', function() {
    offset = offset - 400;
    if (offset < 0) {
        offset = 800;
    }
    sliderRow.style.left = -offset + 'px';
})

let slideIndex = 1;